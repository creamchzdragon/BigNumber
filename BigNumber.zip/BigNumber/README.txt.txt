Project Group :
Jamie Walder, Mantas Pileckis, Justin Davis
Javadoc API link in \doc\index.html or hosted on elvis at: http://elvis.rowan.edu/~pileckism7/BigNumber/BigNumber.html